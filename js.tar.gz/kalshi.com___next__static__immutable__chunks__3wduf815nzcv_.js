(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,881467,t=>{t.v(o=>Promise.all(["static/immutable/chunks/0dmu3owk558uv.js"].map(o=>t.l(o))).then(()=>o(853553)))}]);

//# sourceMappingURL=1zk0nx6wvw9fg.js.map