(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,758186,t=>{t.v(e=>Promise.all(["static/immutable/chunks/2z79dxt7ad69y.js"].map(e=>t.l(e))).then(()=>e(556657)))}]);

//# sourceMappingURL=1zk0nx6wvw9fg.js.map