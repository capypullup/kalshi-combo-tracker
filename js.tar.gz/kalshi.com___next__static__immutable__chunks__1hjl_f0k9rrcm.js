(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,372428,t=>{t.v(e=>Promise.all(["static/immutable/chunks/3x3ar9ge1ax2b.js"].map(e=>t.l(e))).then(()=>e(742974)))}]);

//# sourceMappingURL=1zk0nx6wvw9fg.js.map