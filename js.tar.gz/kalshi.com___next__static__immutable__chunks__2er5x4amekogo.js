(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,966239,t=>{t.v(l=>Promise.all(["static/immutable/chunks/1f255p3_ti_2l.js"].map(l=>t.l(l))).then(()=>l(385610)))},11933,t=>{t.v(l=>Promise.all(["static/immutable/chunks/00-hgsgl9917w.js"].map(l=>t.l(l))).then(()=>l(587517)))}]);

//# sourceMappingURL=1zk0nx6wvw9fg.js.map